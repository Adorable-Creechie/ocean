from . import streams100
from . import soccerstreamlinkscom_soccer

# list of providers
all_providers = [
    # streams100,
    soccerstreamlinkscom_soccer
]
