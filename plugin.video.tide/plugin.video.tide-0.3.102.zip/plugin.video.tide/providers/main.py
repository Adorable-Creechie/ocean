from . import streams100
from . import soccerstreamlinkscom
from . import soccerstreamshdcom

# list of providers
all_providers = [
    streams100,
    soccerstreamlinkscom,
    soccerstreamshdcom
]
