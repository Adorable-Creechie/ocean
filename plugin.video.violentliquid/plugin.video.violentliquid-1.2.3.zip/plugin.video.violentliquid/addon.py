# -*- coding: utf-8 -*-
# std python imports
import json
# import time
import ast
import urllib

# kodi additional plugins
import routing
import requests

# xbmc plugins
import xbmc
import xbmcaddon
# import specific parts of xbmc
from xbmcgui import (
    ListItem,
    Dialog,
    DialogProgress,
)
from xbmcplugin import (
    addDirectoryItem,
    addDirectoryItems,
    addSortMethod,
    endOfDirectory,
    setContent,
    setResolvedUrl,
    SORT_METHOD_VIDEO_TITLE,
    SORT_METHOD_FILE,
    SORT_METHOD_DATE,
)

addon = xbmcaddon.Addon('plugin.video.violentliquid')
api = addon.getSetting("api_url")

# initialize routing
plugin = routing.Plugin()

@plugin.route('/')
def index():
    items = [
        (plugin.url_for(user_index), ListItem("Library"), True),
        (plugin.url_for(torrents_index), ListItem("Torrents"), True),
        # (plugin.url_for(tmdb_index), ListItem("TMDB"), True),
    ]
    addDirectoryItems(plugin.handle, items)

    # free space left
    r_info = requests.get(api + "user/information/")
    information = r_info.json()
    free_space = round(information["freeSpace"] / 1000 / 1000, 2)
    addDirectoryItem(plugin.handle, "", ListItem("Free disk space: %d MB" % free_space))
    # free RAM
    total_mem = round(information["totalMem"] / 1000 / 1000, 2)
    free_mem = round(information["freeMem"] / 1000 / 1000, 2)
    addDirectoryItem(plugin.handle, "", ListItem("Free RAM: %d / %d MB" % (free_mem, total_mem)))

    endOfDirectory(plugin.handle)

@plugin.route("/user")
def user_index():
    # clear library
    clear = ListItem('[B][COLOR red]%s[/COLOR][/B]' % "Clear library")
    clear.setProperty("IsPlayable", "false")
    clear.setProperty("IsFolder", "true")
    addDirectoryItem(plugin.handle,
                        plugin.url_for(user_torrents_delete_all),
                        clear )

    # fetch torrents on disk
    r = requests.get(api + "user/torrents/")
    torrents = r.json()

    for torrent in torrents:
        download_speed = str(round(torrent["downloadSpeed"] / 1000, 2))

        time_left = torrent["ETA"]
        time_scale = "sec"
        if time_left == -1:
            pass
        elif time_left > 60:
            time_left = int(round(time_left / 60, 1))
            time_scale = "min"

        progress = str(round(torrent["progress"] * 100, 1))

        title = u""
        if torrent["progress"] == 1:
            title += u"[COLOR green]§§[/COLOR]"
        else:
            title += u"[COLOR orange]§§[/COLOR]"
        title += u"|" + torrent["dn"] + u"|"
        title += u" (" + download_speed + u" KB/s) "
        title += progress + u"%"
        if time_left != -1:
            title += u" ETA " + str(time_left) + time_scale

        torrent_item = ListItem(title)
        info = {
            "title": torrent["dn"]
        }

        context_menu_items = [
            ('Update', 'Container.Refresh()',),
        ]

        torrent_item.addContextMenuItems(context_menu_items)
        torrent_item.setInfo("video", info)
        addDirectoryItem(plugin.handle, plugin.url_for(user_torrents, query={
            "infoHash": torrent["infoHash"],
            "dn": torrent["dn"]
        }), torrent_item, True)

    endOfDirectory(plugin.handle)

@plugin.route("/user/torrents")
def user_torrents():
    query = plugin.args["query"][0]
    query_m = ast.literal_eval(query)
    infoHash = query_m["infoHash"]
    dn = query_m["dn"]

    # fetch torrent information
    r = requests.get(api + "user/watch/" + infoHash)
    torrent = r.json()

    resource_url = api.replace("v1/", "") + "downloads/"
    # video and subs
    watch = ListItem("Watch")
    video = torrent["video"]
    video_url = resource_url + video;
    video_url = video_url.encode("utf-8")
    video_url = urllib.quote(video_url, safe="%/:=&?~#+!$,;'@()*[]")
    sub = ""
    try:
        sub = torrent["subtitle"]
    except:
        sub = ""
    if sub != "":
        sub_url = urllib.quote(resource_url + sub, safe="%/:=&?~#+!$,;'@()*[]")
        watch.setSubtitles([sub_url])

    info = {
        "title": dn
    }
    watch.setInfo("video", info)
    addDirectoryItem(plugin.handle, video_url, watch)

    # files in torrent
    files_item = ListItem("View files")
    files_item.setProperty("IsFolder", "true")
    addDirectoryItem(plugin.handle,
                     plugin.url_for(user_torrents_files,
                                    query={"infoHash": infoHash, "dn": dn},
    ), files_item, True)

    # delete torrent
    li = ListItem("Delete")
    li.setProperty("IsPlayable", "false")
    li.setProperty("IsFolder", "true")
    addDirectoryItem(plugin.handle,
                        plugin.url_for(user_torrents_delete, query=infoHash),
                        li)

    endOfDirectory(plugin.handle)

def find_subs(files, filename):
    resource_url = api.replace("v1/", "") + "downloads/"
    subs = []
    stem = ('.').join(filename.split('.')[:-1]).lower()

    for f in files:
        fn = f[0].split("/")[-1]
        stemp = ('.').join(fn.split('.')[:-1]).lower()
        extp = fn.split('.')[-1].lower()
        if extp == "srt" and stemp == stem:
            sub_url = resource_url + f[0];
            sub_url = sub_url.encode("utf-8")
            sub_url = urllib.quote(sub_url, safe="%/:=&?~#+!$,;'@()*[]")
            subs.append(sub_url)
            break

    return subs

@plugin.route("/user/torrents/files")
def user_torrents_files():
    setContent(plugin.handle, 'videos')
    query = plugin.args["query"][0]
    query_m = ast.literal_eval(query)
    infoHash = query_m["infoHash"]
    dn = query_m["dn"]

    # request files
    req_url = api + "user/files/" + infoHash
    r = requests.get(api + "user/files/" + infoHash)
    files = r.json()
    files = files["files"]

    resource_url = api.replace("v1/", "") + "downloads/"
    for f in files:
        title = f[0].split("/")[-1]
        li = ListItem(title)
        li.setInfo('video', {'title': title,
                                    'mediatype': 'video'})
        file_url = resource_url + f[0];
        file_url = file_url.encode("utf-8")
        file_url = urllib.quote(file_url, safe="%/:=&?~#+!$,;'@()*[]")
        li.setSubtitles(find_subs(files, title))
        addDirectoryItem(plugin.handle, file_url, li)

    addSortMethod(plugin.handle, SORT_METHOD_FILE);

    endOfDirectory(plugin.handle)

@plugin.route("/user/torrents/delete")
def user_torrents_delete():
    infoHash = plugin.args["query"][0]
    r = requests.delete(api + "user/torrents/" + infoHash)
    rd = plugin.url_for(user_index)
    Dialog().notification("Deleted", "Torrent deleted.")
    xbmc.executebuiltin('XBMC.Container.Refresh(''%s'')' % rd)

@plugin.route("/user/torrents/deleteAll")
def user_torrents_delete_all():
    confirmation = Dialog().yesno("Confirmation", "Do you really want to clear the library?")
    if confirmation:
        r = requests.delete(api + "user/torrents/deleteAll/")
        rd = plugin.url_for(index)
        Dialog().notification("Cleared", "Library cleared.")
        xbmc.executebuiltin('XBMC.Container.Refresh(''%s'')' % rd)

@plugin.route("/torrents")
def torrents_index():
    addDirectoryItem(plugin.handle,
                     plugin.url_for(torrents_movies_search),
                     ListItem("Movies"),
                     True)
    addDirectoryItem(plugin.handle,
                     plugin.url_for(torrents_shows_search),
                     ListItem("TV Shows"),
                     True)
    endOfDirectory(plugin.handle)

@plugin.route("/torrents/search/movies")
def torrents_movies_search():
    keyboard = xbmc.Keyboard()
    keyboard.setHeading("Search - Movies")
    keyboard.doModal()
    query = keyboard.getText()
    if query:
        # fetch torrent search results
        r = requests.get(api + "torrents/movies/" + query)
        torrents = r.json()

        if (len(torrents) == 0):
            Dialog().ok("Error", "No results found.")
            return

        for torrent in torrents:
            name = torrent["name"]
            size = torrent["size"]
            human_size = round(round(size, 2) / 1000 / 1000, 2)
            human_scale = "MB"
            if human_size > 1000:
                human_size /= 1000
                human_size = round(human_size, 2)
                human_scale = "GB"
            seeders = torrent["seeders"]
            leechers = torrent["leechers"]

            title = str(seeders) + "/" + str(leechers) + " || ("
            title += str(human_size) + human_scale + ") " + name
            li = ListItem(title)
            li.setInfo('audio', {'date': seeders})
            li.setProperty("IsPlayable", "false")
            li.setProperty("IsFolder", "true")
            magnet = torrent["magnet"]

            url = plugin.url_for(user_torrents_post, query={
                "magnet": magnet,
                "size": size
            })
            addDirectoryItem(plugin.handle,
                             url,
                             li)

        addSortMethod(plugin.handle, SORT_METHOD_DATE);
        endOfDirectory(plugin.handle)

@plugin.route("/user/torrents/post")
def user_torrents_post():
    query = plugin.args["query"][0]
    query_m = ast.literal_eval(query)
    magnet = query_m["magnet"]
    size = query_m["size"]

    Dialog().notification("Added", "Torrent added. Wait for it to finish before watching.")

    # post magnet to server
    post_url = api + "user/torrents/"
    headers = {'Content-type': 'application/json'}
    data = {
        "magnet": magnet,
        "size": size,
    }
    r = requests.post(post_url, data=json.dumps(data), headers=headers)
    rd = plugin.url_for(user_index)

    xbmc.executebuiltin('XBMC.Container.Refresh(''%s'')' % rd)

@plugin.route("/torrents/search/shows")
def torrents_shows_search():
    keyboard = xbmc.Keyboard()
    keyboard.setHeading("Search - TV Shows")
    keyboard.doModal()
    query = keyboard.getText()
    if query:
        # fetch torrent search results
        r = requests.get(api + "torrents/shows/" + query)
        torrents = r.json()

        if (len(torrents) == 0):
            Dialog().ok("Error", "No results found.")
            return

        for torrent in torrents:
            name = torrent["name"]
            size = torrent["size"]
            human_size = round(round(size, 2) / 1000 / 1000, 2)
            human_scale = "MB"
            if human_size > 1000:
                human_size /= 1000
                human_size = round(human_size, 2)
                human_scale = "GB"
            seeders = torrent["seeders"]
            leechers = torrent["leechers"]

            title = str(seeders) + "/" + str(leechers) + " || ("
            title += str(human_size) + human_scale + ") " + name
            li = ListItem(title)
            li.setProperty("IsPlayable", "false")
            li.setProperty("IsFolder", "true")
            li.setInfo('audio', {'date': seeders})
            magnet = torrent["magnet"]

            url = plugin.url_for(user_torrents_post, query={
                "magnet": magnet,
                "size": size
            })
            addDirectoryItem(plugin.handle,
                             url,
                             li)
        addSortMethod(plugin.handle, SORT_METHOD_DATE);
        endOfDirectory(plugin.handle)

@plugin.route("/tmdb")
def tmdb_index():
    addDirectoryItem(plugin.handle, "", ListItem("Movies"))
    endOfDirectory(plugin.handle)

if __name__ == '__main__':
    plugin.run()
